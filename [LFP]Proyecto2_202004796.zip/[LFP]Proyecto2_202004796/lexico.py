import re
import string
from tkinter import Tk, filedialog as fd

list_tkn = []
list_sintactico = []
list_err = []
data = ""


class tkn:
    def __init__(self, token, lexema, linea):
        self.token = token
        self.lexema = lexema
        self.linea = linea
        pass

    def gettoken(self):
        return self.token

    def getlexema(self):
        return self.lexema

    def getlinea(self):
        return self.linea


class err:
    def __init__(self, lexema, linea, tipo="LEXICO",):
        self.tipo = tipo
        self.lexema = lexema
        self.linea = linea

    def gettipo(self):
        return self.tipo

    def getlexema(self):
        return self.lexema

    def getlinea(self):
        return self.linea


def analizar(texto):
    global list_tkn, list_err, list_sintactico


    palabra = ""
    estado = 0
    linea = 1
    texto=texto+" #"

    i = 0
    while i < len(texto):
        c = texto[i]
        if estado == 0:
            # print(c)
            # ESTADO INICIAL -> signos
            if c == "<":
                palabra = palabra + c
                x = tkn("MENOR QUE", palabra, linea)
                list_tkn.append(x)
                list_sintactico.append(x)
                palabra = ""
                estado = 0
            elif c == ">":
                palabra = palabra + c
                x = tkn("MAYOR QUE", palabra, linea)
                list_tkn.append(x)
                list_sintactico.append(x)
                palabra = ""
                estado = 0
            elif re.search('[a-zA-Z]', c):
                palabra += c
                estado = 1
            elif c == " " or c == "\t":
                estado = 0
            elif c == "\n":
                linea = linea + 1
                estado = 0
            elif c == "\"":

                palabra += c
                estado = 2
            elif c.isdigit():
                palabra += c
                estado = 3
            elif c == "-":

                palabra += c
                estado = 4
            elif c == "_":
                estado = 0
            elif c == "#":
                x = tkn("CENTINELA", c, linea)
                list_tkn.append(x)
                list_sintactico.append(x)
                palabra = ""
            else:
                palabra = palabra + c
                xer = err(palabra, linea)
                list_err.append(xer)
                palabra = ""
                estado = 0
        elif estado == 1:
            # ESTADO 1 -> letras
            if re.search("[a-zA-Z]", c):
                palabra = palabra + c
                estado = 1
            elif c=="_":
                palabra = palabra + c
                estado = 1
            elif c.isdigit():
                palabra = palabra + c
                estado = 1
            else:
                # Obtener el tipo de token
                # print(palabra)
                tipo = ""
                if palabra == "RESULTADO":
                    tipo = "RESULTADO"
                elif palabra == "VS":
                    tipo = "VS"
                elif palabra == "TEMPORADA":
                    tipo = "TEMPORADA"
                elif palabra == "JORNADA":
                    tipo = "JORNADA"
                elif palabra == "GOLES":
                    tipo = "GOLES"
                elif palabra == "LOCAL":
                    tipo = "LOCAL"
                elif palabra == "VISITANTE":
                    tipo = "VISITANTE"
                elif palabra == "TOTAL":
                    tipo = "TOTAL"
                elif palabra == "TABLA":
                    tipo = "TABLA"
                elif palabra == "PARTIDOS":
                    tipo = "PARTIDOS"
                elif palabra == "TOP":
                    tipo = "TOP"
                elif palabra == "SUPERIOR":
                    tipo = "SUPERIOR"
                elif palabra == "INFERIOR":
                    tipo = "INFERIOR"
                elif palabra == "ADIOS":
                    tipo = "ADIOS"
                else:
                    x = tkn("INSTRUCCION", palabra, linea)
                    list_tkn.append(x)
                    list_sintactico.append(x)
                    palabra = ""
                    estado = 0

                    continue
                # Crear el token
                x = tkn(tipo, palabra, linea)
                list_tkn.append(x)
                list_sintactico.append(x)
                palabra = ""
                estado = 0
                i -= 1
        elif estado == 2:

            # ESTADO 2 -> cadena
            if c == "\"":
                palabra = palabra + c
                x = tkn("CADENA", palabra, linea)
                list_tkn.append(x)
                list_sintactico.append(x)
                palabra = ""
                estado = 0
            elif c == "\n":
                linea = linea + 1
                palabra = palabra + c
                estado = 2
            else:
                palabra = palabra + c
                estado = 2
        elif estado == 3:
            # ESTADO 3 -> entero
            if c.isdigit():
                palabra = palabra + c
                estado = 3
            else:
                x = tkn("ENTERO", palabra, linea)
                list_tkn.append(x)
                list_sintactico.append(x)
                palabra = ""
                estado = 0
                i=i-1
        elif estado == 4:
            # ESTADO 4 -> instrucciones
            if re.search("[a-zA-Z]", c):
                palabra = palabra + c
                estado = 4
            else:
                # Obtener el tipo de token
                # print(p
                tipo = ""
                if palabra.lower() == "-f":
                    tipo = "BANDERA_f"
                elif palabra.lower() == "-n":
                    tipo = "BANDERA_n"
                elif palabra.lower() == "-ji":
                    tipo = "BANDERA_ji"
                elif palabra.lower() == "-jf":
                    tipo = "BANDERA_jf"
                else:
                    tipo = "GUION"
                # Crear el token
                x = tkn(tipo, palabra, linea)
                list_tkn.append(x)
                list_sintactico.append(x)
                palabra = ""
                estado = 0
                i -= 1
        i = i + 1


def imprimir_lsts():
    print(len(list_sintactico))
    for x in list_sintactico:
        print(x.gettoken())


def limpiar_err():
    global list_err
    list_err=[]

def limpiar_tkn():
    global list_tkn
    list_tkn=[]

def limpiar_sintactico():
    global list_sintactico
    list_sintactico=[]

def html_tkn():
    ####### Comienza html
    with open('tokens.html', 'w') as f:
        f.write("<!DOCTYPE html>\n"
                "<html>\n"
                "<head>\n"
                "<title>Lista de Tokens</title>\n"
                '<link rel="stylesheet" href="tkn.css">\n'
                "</head>\n"
                "<body>\n"
                '<div id="main-container">\n'
                "<h1>Lista de Tokens</h1>\n"
                "<p>Creado por: Gerhard Benjamin Ardon Valdez 202004796</p>\n"
                "<table>\n"
                "<thead>\n"
                "<tr>\n"
                "<th>Token</th><th>Lexema</th><th>Linea</th>\n"
                "</tr>\n"
                "</thead>\n")

        ####### IMPRIMIR LOS OBJETOS

        for x in list_tkn:
            f.write("<tr><td>" + str(x.gettoken()) + "</td><td>" + str(x.getlexema()) + "</td><td>" + str(
                x.getlinea()) + "</td>\n</tr>")

        f.write("</table>\n"

                "</div>\n"
                "</body>\n"
                "</html>")

def html_err():
    with open('errores.html', 'w') as f:
        f.write("<!DOCTYPE html>\n"
                "<html>\n"
                "<head>\n"
                "<title>Lista de Errores</title>\n"
                '<link rel="stylesheet" href="err.css">\n'
                "</head>\n"
                "<body>\n"
                '<div id="main-container">\n'
                "<h1>Lista de Errores</h1>\n"
                "<p>Creado por: Gerhard Benjamin Ardon Valdez 202004796</p>\n"
                "<table>\n"
                "<thead>\n"
                "<tr>\n"
                "<th>Tipo</th><th>Lexema</th><th>Linea</th>\n"
                "</tr>\n"
                "</thead>\n")

        ####### IMPRIMIR LOS OBJETOS

        for x in list_err:
            f.write("<tr><td>" + str(x.gettipo()) + "</td><td>" + str(x.getlexema()) + "</td><td>" + str(
                x.getlinea()) + "</td>\n</tr>")

        f.write("</table>\n"

                "</div>\n"
                "</body>\n"
                "</html>")