from lexico import *
from main import *


class sintactico:
    def __init__(self):
        self.listaTokens = []
        self.listaErrores = []
        self.i = 0
        self.error = False

    def analizar_lex(self, listaTokens, listaErrores):
        self.listaTokens = []
        self.listaTokens = listaTokens
        self.listaErrores = listaErrores
        return self.inicio()

    def inicio(self):
        token = self.listaTokens[self.i]
        print(token.token)
        self.comando_bot()
        token = self.listaTokens[self.i]

        if token.token == 'CENTINELA' and self.error == False:
            print('Analisis sintactico exitoso')
            msg = "Entiendo a la perfeccion, un momento :)..."
            return msg
        else:
            msg = "No entiendo lo que dices, revisa tu mensaje :/"
            return msg

    def comando_bot(self):
        token = self.listaTokens[self.i]
        print(token.token)
        if token.token == "RESULTADO":
            self.res_partido()
        elif token.token == "JORNADA":
            self.res_jornada()
            pass
        elif token.token == "GOLES":
            self.goles()
            pass
        elif token.token == "TABLA":
            self.tabla()
            pass
        elif token.token == "PARTIDOS":
            self.temp_equipos()
            pass
        elif token.token == "TOP":
            self.top_equipos()
            pass
        elif token.token == "ADIOS":
            self.salida()
            pass
        elif token.token == "CENTINELA":
            pass
        else:
            xer = err(token.lexema, token.linea, "SINTACTICO")
            self.listaErrores.append(xer)

    def res_partido(self):
        token = self.listaTokens[self.i]
        if token.token == "RESULTADO":
            print(token.token)
            self.i += 1
            token = self.listaTokens[self.i]
            if token.token == "CADENA":
                print(token.token)
                local = token.lexema
                self.i += 1
                token = self.listaTokens[self.i]
                if token.token == "VS":
                    print(token.token)
                    self.i += 1
                    token = self.listaTokens[self.i]
                    if token.token == "CADENA":
                        print(token.token)
                        visitante = token.lexema
                        self.i += 1
                        token = self.listaTokens[self.i]
                        if token.token == "TEMPORADA":
                            print(token.token)
                            self.i += 1
                            token = self.listaTokens[self.i]
                            if token.token == "MENOR QUE":
                                print(token.token)
                                self.i += 1
                                token = self.listaTokens[self.i]
                                if token.token == "ENTERO":
                                    print(token.token)
                                    temporada = token.lexema
                                    self.i += 1
                                    token = self.listaTokens[self.i]
                                    if token.token == "GUION":
                                        print(token.token)
                                        temporada = temporada + "-"
                                        self.i += 1
                                        token = self.listaTokens[self.i]
                                        if token.token == "ENTERO":
                                            print(token.token)
                                            temporada = temporada + token.lexema
                                            local = local.replace('"', '')
                                            visitante = visitante.replace('"', '')
                                            print(local, visitante, temporada)
                                            search_resultado(local, visitante, temporada)
                                            self.i += 1
                                            token = self.listaTokens[self.i]
                                            if token.token == "MAYOR QUE":
                                                print(token.token)
                                                self.i += 1
                                            else:
                                                print("se esperaba MAYOR")
                                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                                list_err.append(xer)
                                                self.error = True
                                        else:
                                            print("se esperaba ENTERO")
                                            xer = err(token.lexema, token.linea, "SINTACTICO")
                                            list_err.append(xer)
                                            self.error = True
                                    else:
                                        print("se esperaba GUION")
                                        self.error = True
                                else:
                                    print("se esperaba ENTERO")
                                    xer = err(token.lexema, token.linea, "SINTACTICO")
                                    list_err.append(xer)
                                    self.error = True
                            else:
                                print("se esperaba MENOR")
                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                list_err.append(xer)
                                self.error = True
                        else:
                            print("se esperaba TEMPORADA")
                            xer = err(token.lexema, token.linea, "SINTACTICO")
                            list_err.append(xer)
                            self.error = True
                    else:
                        print("se esperaba CADENA")
                        xer = err(token.lexema, token.linea, "SINTACTICO")
                        list_err.append(xer)
                        self.error = True
                else:
                    print("se esperaba VS")
                    xer = err(token.lexema, token.linea, "SINTACTICO")
                    list_err.append(xer)
                    self.error = True
            else:
                print("se esperaba CADENA")
                xer = err(token.lexema, token.linea, "SINTACTICO")
                list_err.append(xer)
                self.error = True
        else:
            print("se esperaba RESULTADO")
            xer = err(token.lexema, token.linea, "SINTACTICO")
            list_err.append(xer)
            self.error = True

    def res_jornada(self):
        token = self.listaTokens[self.i]
        if token.token == "JORNADA":
            print(token.token)
            self.i += 1
            token = self.listaTokens[self.i]
            if token.token == "ENTERO":
                print(token.token)
                jornada = token.lexema
                self.i += 1
                token = self.listaTokens[self.i]
                if token.token == "TEMPORADA":
                    print(token.token)
                    self.i += 1
                    token = self.listaTokens[self.i]
                    if token.token == "MENOR QUE":
                        print(token.token)
                        self.i += 1
                        token = self.listaTokens[self.i]
                        if token.token == "ENTERO":
                            print(token.token)
                            temporada = token.lexema
                            self.i += 1
                            token = self.listaTokens[self.i]
                            if token.token == "GUION":
                                print(token.token)
                                temporada += "-"
                                self.i += 1
                                token = self.listaTokens[self.i]
                                if token.token == "ENTERO":
                                    print(token.token)
                                    temporada += token.lexema
                                    self.i += 1
                                    token = self.listaTokens[self.i]
                                    if token.token == "MAYOR QUE":
                                        print(token.token)
                                        self.i += 1
                                        token = self.listaTokens[self.i]
                                        if token.token == "BANDERA_f":
                                            print(token.token)
                                            self.i += 1
                                            token = self.listaTokens[self.i]
                                            if token.token == "INSTRUCCION":
                                                print(token.token)
                                                name = token.lexema
                                                search_jornada(jornada, temporada, name)
                                                self.i += 1
                                            else:
                                                print("se esperaba INSTRUCCION")
                                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                                list_err.append(xer)
                                                self.error = True
                                        else:
                                            self.i += 1
                                    else:
                                        print("se esperaba MAYOR")
                                        xer = err(token.lexema, token.linea, "SINTACTICO")
                                        list_err.append(xer)
                                        self.error = True

                                else:
                                    print("se esperaba ENTERO")
                                    xer = err(token.lexema, token.linea, "SINTACTICO")
                                    list_err.append(xer)
                                    self.error = True
                            else:
                                print("se esperaba GUION")
                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                list_err.append(xer)
                                self.error = True
                        else:
                            print("se esperaba ENTERO")
                            xer = err(token.lexema, token.linea, "SINTACTICO")
                            list_err.append(xer)
                            self.error = True
                    else:
                        print("se esperaba MENOR")
                        xer = err(token.lexema, token.linea, "SINTACTICO")
                        list_err.append(xer)
                        self.error = True
                else:
                    print("se esperaba TEMPORADA")
                    xer = err(token.lexema, token.linea, "SINTACTICO")
                    list_err.append(xer)
                    self.error = True
            else:
                print("se esperaba ENTERO")
                xer = err(token.lexema, token.linea, "SINTACTICO")
                list_err.append(xer)
                self.error = True
        else:
            print("se esperaba JORNADA")
            xer = err(token.lexema, token.linea, "SINTACTICO")
            list_err.append(xer)
            self.error = True

    def goles(self):
        token = self.listaTokens[self.i]
        if token.token == "GOLES":
            print(token.token)
            self.i += 1
            token = self.listaTokens[self.i]
            if token.token == "LOCAL" or token.token == "VISITANTE" or token.token == "TOTAL":
                print(token.token)
                condicion = token.lexema
                self.i += 1
                token = self.listaTokens[self.i]
                if token.token == "CADENA":
                    print(token.token)
                    equipo = token.lexema
                    equipo=equipo.replace('"','')
                    self.i += 1
                    token = self.listaTokens[self.i]
                    if token.token == "TEMPORADA":
                        print(token.token)
                        self.i += 1
                        token = self.listaTokens[self.i]
                        if token.token == "MENOR QUE":
                            print(token.token)
                            self.i += 1
                            token = self.listaTokens[self.i]
                            if token.token == "ENTERO":
                                print(token.token)
                                temporada = token.lexema
                                self.i += 1
                                token = self.listaTokens[self.i]
                                if token.token == "GUION":
                                    print(token.token)
                                    temporada += "-"
                                    self.i += 1
                                    token = self.listaTokens[self.i]
                                    if token.token == "ENTERO":
                                        print(token.token)
                                        temporada += token.lexema
                                        search_goles(condicion, equipo, temporada)
                                        self.i += 1
                                        token = self.listaTokens[self.i]
                                        if token.token == "MAYOR QUE":
                                            print(token.token)
                                            self.i += 1

                                        else:
                                            print("se esperaba MAYOR")
                                            xer = err(token.lexema, token.linea, "SINTACTICO")
                                            list_err.append(xer)
                                            self.error = True

                                    else:
                                        print("se esperaba ENTERO")
                                        xer = err(token.lexema, token.linea, "SINTACTICO")
                                        list_err.append(xer)
                                        self.error = True
                                else:
                                    print("se esperaba GUION")
                                    xer = err(token.lexema, token.linea, "SINTACTICO")
                                    list_err.append(xer)
                                    self.error = True
                            else:
                                print("se esperaba ENTERO")
                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                list_err.append(xer)
                                self.error = True
                        else:
                            print("se esperaba MENOR")
                            xer = err(token.lexema, token.linea, "SINTACTICO")
                            list_err.append(xer)
                            self.error = True
                    else:
                        print("se esperaba TEMPORADA")
                        xer = err(token.lexema, token.linea, "SINTACTICO")
                        list_err.append(xer)
                        self.error = True
                else:
                    print("se esperaba CADENA")
                    xer = err(token.lexema, token.linea, "SINTACTICO")
                    list_err.append(xer)
                    self.error = True
            else:
                print("se esperaba CONDICION")
                xer = err(token.lexema, token.linea, "SINTACTICO")
                list_err.append(xer)
                self.error = True
        else:
            print("se esperaba GOLES")
            xer = err(token.lexema, token.linea, "SINTACTICO")
            list_err.append(xer)
            self.error = True

    def tabla(self):
        token = self.listaTokens[self.i]
        if token.token == "TABLA":
            print(token.token)
            self.i += 1
            token = self.listaTokens[self.i]
            if token.token == "TEMPORADA":
                print(token.token)
                self.i += 1
                token = self.listaTokens[self.i]
                if token.token == "MENOR QUE":
                    print(token.token)
                    self.i += 1
                    token = self.listaTokens[self.i]
                    if token.token == "ENTERO":
                        print(token.token)
                        self.i += 1
                        token = self.listaTokens[self.i]
                        if token.token == "GUION":
                            print(token.token)
                            self.i += 1
                            token = self.listaTokens[self.i]
                            if token.token == "ENTERO":
                                print(token.token)
                                self.i += 1
                                token = self.listaTokens[self.i]
                                if token.token == "MAYOR QUE":
                                    print(token.token)
                                    self.i += 1
                                    token = self.listaTokens[self.i]
                                    if token.token == "BANDERA_f":
                                        print(token.token)
                                        self.i += 1
                                        token = self.listaTokens[self.i]
                                        if token.token == "INSTRUCCION":
                                            print(token.token)
                                            self.i += 1
                                        else:
                                            print("se esperaba INSTRUCCION")
                                            xer = err(token.lexema, token.linea, "SINTACTICO")
                                            list_err.append(xer)
                                            self.error = True
                                    else:
                                        pass
                                else:
                                    print("se esperaba MAYOR")
                                    xer = err(token.lexema, token.linea, "SINTACTICO")
                                    list_err.append(xer)
                                    self.error = True
                            else:
                                print("se esperaba ENTERO")
                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                list_err.append(xer)
                                self.error = True
                        else:
                            print("se esperaba GUION")
                            xer = err(token.lexema, token.linea, "SINTACTICO")
                            list_err.append(xer)
                            self.error = True
                    else:
                        print("se esperaba ENTERO")
                        xer = err(token.lexema, token.linea, "SINTACTICO")
                        list_err.append(xer)
                        self.error = True
                else:
                    print("se esperaba MENOR")
                    xer = err(token.lexema, token.linea, "SINTACTICO")
                    list_err.append(xer)
                    self.error = True
            else:
                print("se esperaba TEMPORADA")
                xer = err(token.lexema, token.linea, "SINTACTICO")
                list_err.append(xer)
                self.error = True
        else:
            print("se esperaba TABLA")
            xer = err(token.lexema, token.linea, "SINTACTICO")
            list_err.append(xer)
            self.error = True

    def temp_equipos(self):
        token = self.listaTokens[self.i]
        if token.token == "PARTIDOS":
            print(token.token)
            self.i += 1
            token = self.listaTokens[self.i]
            if token.token == "CADENA":
                print(token.token)
                self.i += 1
                token = self.listaTokens[self.i]
                if token.token == "TEMPORADA":
                    print(token.token)
                    self.i += 1
                    token = self.listaTokens[self.i]
                    if token.token == "MENOR QUE":
                        print(token.token)
                        self.i += 1
                        token = self.listaTokens[self.i]
                        if token.token == "ENTERO":
                            print(token.token)
                            self.i += 1
                            token = self.listaTokens[self.i]
                            if token.token == "GUION":
                                print(token.token)
                                self.i += 1
                                token = self.listaTokens[self.i]
                                if token.token == "ENTERO":
                                    print(token.token)
                                    self.i += 1
                                    token = self.listaTokens[self.i]
                                    if token.token == "MAYOR QUE":
                                        print(token.token)
                                        self.i += 1
                                        token = self.listaTokens[self.i]
                                        if token.token == "BANDERA_f":
                                            print(token.token)
                                            self.i += 1
                                            token = self.listaTokens[self.i]
                                            if token.token == "INSTRUCCION":
                                                print(token.token)
                                                self.i += 1
                                            else:
                                                print("se esperaba INSTRUCCION")
                                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                                list_err.append(xer)
                                                self.error = True
                                        elif token.token == "BANDERA_ji":
                                            print(token.token)
                                            self.i += 1
                                            token = self.listaTokens[self.i]
                                            if token.token == "ENTERO":
                                                print(token.token)
                                                self.i += 1
                                                token = self.listaTokens[self.i]
                                                if token.token == "BANDERA_jf":
                                                    print(token.token)
                                                    self.i += 1
                                                    token = self.listaTokens[self.i]
                                                    if token.token == "ENTERO":
                                                        print(token.token)
                                                        self.i += 1

                                                    else:
                                                        print("se esperaba ENTERO")
                                                        xer = err(token.lexema, token.linea, "SINTACTICO")
                                                        list_err.append(xer)
                                                        self.error = True
                                                else:
                                                    print("se esperaba BANDERA_jf")
                                                    xer = err(token.lexema, token.linea, "SINTACTICO")
                                                    list_err.append(xer)
                                                    self.error = True
                                            else:
                                                print("se esperaba ENTERO")
                                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                                list_err.append(xer)
                                                self.error = True
                                        else:
                                            self.i += 1
                                    else:
                                        print("se esperaba MAYOR QUE")
                                        xer = err(token.lexema, token.linea, "SINTACTICO")
                                        list_err.append(xer)
                                        self.error = True
                                else:
                                    print("se esperaba ENTERO")
                                    xer = err(token.lexema, token.linea, "SINTACTICO")
                                    list_err.append(xer)
                                    self.error = True
                            else:
                                print("se esperaba GUION")
                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                list_err.append(xer)
                                self.error = True
                        else:
                            print("se esperaba ENTERO")
                            xer = err(token.lexema, token.linea, "SINTACTICO")
                            list_err.append(xer)
                            self.error = True
                    else:
                        print("se esperaba MENOR QUE ")
                        xer = err(token.lexema, token.linea, "SINTACTICO")
                        list_err.append(xer)
                        self.error = True
                else:
                    print("se esperaba TEMPORADA")
                    xer = err(token.lexema, token.linea, "SINTACTICO")
                    list_err.append(xer)
                    self.error = True
            else:
                print("se esperaba CADENA")
                xer = err(token.lexema, token.linea, "SINTACTICO")
                list_err.append(xer)
                self.error = True
        else:
            print("se esperaba PARTIDOS")
            xer = err(token.lexema, token.linea, "SINTACTICO")
            list_err.append(xer)
            self.error = True

    def top_equipos(self):
        token = self.listaTokens[self.i]
        if token.token == "TOP":
            print(token.token)
            self.i += 1
            token = self.listaTokens[self.i]
            if token.token == "SUPERIOR" or token.token == "INFERIOR" or token.token == "TOTAL":
                print(token.token)
                self.i += 1
                token = self.listaTokens[self.i]
                if token.token == "TEMPORADA":
                    print(token.token)
                    self.i += 1
                    token = self.listaTokens[self.i]
                    if token.token == "MENOR QUE":
                        print(token.token)
                        self.i += 1
                        token = self.listaTokens[self.i]
                        if token.token == "ENTERO":
                            print(token.token)
                            self.i += 1
                            token = self.listaTokens[self.i]
                            if token.token == "GUION":
                                print(token.token)
                                self.i += 1
                                token = self.listaTokens[self.i]
                                if token.token == "ENTERO":
                                    print(token.token)
                                    self.i += 1
                                    token = self.listaTokens[self.i]
                                    if token.token == "MAYOR QUE":
                                        print(token.token)
                                        self.i += 1
                                        token = self.listaTokens[self.i]
                                        if token.token == "BANDERA_n":
                                            print(token.token)
                                            self.i += 1
                                            token = self.listaTokens[self.i]
                                            if token.token == "ENTERO":
                                                print(token.token)
                                                self.i += 1
                                            else:
                                                print("se esperaba ENTERO")
                                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                                list_err.append(xer)
                                                self.error = True
                                        else:
                                            self.i += 1
                                    else:
                                        print("se esperaba MAYOR")
                                        xer = err(token.lexema, token.linea, "SINTACTICO")
                                        list_err.append(xer)
                                        self.error = True

                                else:
                                    print("se esperaba ENTERO")
                                    xer = err(token.lexema, token.linea, "SINTACTICO")
                                    list_err.append(xer)
                                    self.error = True
                            else:
                                print("se esperaba GUION")
                                xer = err(token.lexema, token.linea, "SINTACTICO")
                                list_err.append(xer)
                                self.error = True
                        else:
                            print("se esperaba ENTERO")
                            xer = err(token.lexema, token.linea, "SINTACTICO")
                            list_err.append(xer)
                            self.error = True
                    else:
                        print("se esperaba MENOR")
                        xer = err(token.lexema, token.linea, "SINTACTICO")
                        list_err.append(xer)
                        self.error = True
                else:
                    print("se esperaba TEMPORADA")
                    xer = err(token.lexema, token.linea, "SINTACTICO")
                    list_err.append(xer)
                    self.error = True
            else:
                print("se esperaba CONDICION")
                xer = err(token.lexema, token.linea, "SINTACTICO")
                list_err.append(xer)
                self.error = True
        else:
            print("se esperaba TOP")
            xer = err(token.lexema, token.linea, "SINTACTICO")
            list_err.append(xer)
            self.error = True

    def salida(self):
        token = self.listaTokens[self.i]
        if token.token == "ADIOS":
            print(token.token)
            self.i += 1
            exit()
        else:
            print("se esperaba ADIOS")
            xer = err(token.lexema, token.linea, "SINTACTICO")
            list_err.append(xer)
            self.error = True


def search_resultado(local, visitante, temporada):
    print(len(lst_partidos))
    for x in lst_partidos:
        if local == x.getlocal() and visitante == x.getvisitante() and temporada == x.gettemporada():
            print("encontradooooooooooooo")
            x.imprimir()
            with open('resultado.html', 'w') as f:
                f.write("<!DOCTYPE html>\n"
                        "<html>\n"
                        "<head>\n"
                        "<title>RESULTADO</title>\n"
                        '<link rel="stylesheet" href="tkn.css">\n'
                        "</head>\n"
                        "<body>\n"
                        '<div id="main-container">\n'
                        "<h1>RESULTADO DE PARTIDO</h1>\n"
                        "<p>Creado por: Gerhard Benjamin Ardon Valdez 202004796</p>\n"
                        "<table>\n"
                        "<thead>\n"
                        "<tr>\n"
                        "<th>Local</th><th>Visitante</th>\n"
                        "</tr>\n"
                        "</thead>\n")

                ####### IMPRIMIR LOS OBJETOS

                f.write("<tr><td>" + str(x.getlocal()) + " " + str(x.getgol_local()) + "</td><td>" + str(
                    x.getvisitante()) + " " + str(x.getgol_visita()) + "</td>\n</tr>")

                f.write("</table>\n"

                        "</div>\n"
                        "</body>\n"
                        "</html>")

            webbrowser.open_new_tab('resultado.html')


def search_jornada(jornada, temporada, name):
    with open(name + '.html', 'w') as f:
        f.write("<!DOCTYPE html>\n"
                "<html>\n"
                "<head>\n"
                "<title>RESULTADO</title>\n"
                '<link rel="stylesheet" href="tkn.css">\n'
                "</head>\n"
                "<body>\n"
                '<div id="main-container">\n'
                "<h1>Resultados Jornada " + jornada + " \n" + temporada + "</h1>\n"
                                                                          "<p>Creado por: Gerhard Benjamin Ardon Valdez 202004796</p>\n"
                                                                          "<table>\n"
                                                                          "<thead>\n"
                                                                          "<tr>\n"
                                                                          "<th>Local</th><th>Visitante</th>\n"
                                                                          "</tr>\n"
                                                                          "</thead>\n")

        ####### IMPRIMIR LOS OBJETOS

        for x in lst_partidos:
            if jornada == x.getjornada() and temporada == x.gettemporada():
                f.write("<tr><td>" + str(x.getlocal()) + " " + str(x.getgol_local()) + "</td><td>" + str(
                    x.getvisitante()) + " " + str(x.getgol_visita()) + "</td>\n</tr>")

        f.write("</table>\n"

                "</div>\n"
                "</body>\n"
                "</html>")

    webbrowser.open_new_tab(name + '.html')


def search_goles(condicion, equipo, temporada):
    print(condicion,equipo,temporada)
    if condicion == "LOCAL":
        goles = 0
        for x in lst_partidos:
            if equipo == x.getlocal() and temporada == x.gettemporada():
                i= int(x.getgol_local())
                goles = goles + i
        print(goles)
    elif condicion == "VISITANTE":
        goles = 0
        for x in lst_partidos:
            if equipo == x.getvisitante() and temporada == x.gettemporada():
                i = int(x.getgol_visita())
                goles = goles + i
        print(goles)
    elif condicion == "TOTAL":
        goles = 0
        for x in lst_partidos:
            if equipo == x.getlocal() and temporada == x.gettemporada():
                i = int(x.getgol_local())
                goles = goles + i
        for x in lst_partidos:
            if equipo == x.getvisitante() and temporada == x.gettemporada():
                i = int(x.getgol_visita())
                goles = goles + i
        print(goles)
    with open('goles.html', 'w') as f:
        f.write("<!DOCTYPE html>\n"
                "<html>\n"
                "<head>\n"
                "<title>RESULTADO</title>\n"
                '<link rel="stylesheet" href="tkn.css">\n'
                "</head>\n"
                "<body>\n"
                '<div id="main-container">\n'
                "<h1>Goles Temporada "+temporada+"</h1>\n"
                "<p>Creado por: Gerhard Benjamin Ardon Valdez 202004796</p>\n"
                "<table>\n"
                "<thead>\n"
                "<tr>\n"
                "<th>Condicion</th><th>Equipo</th><th>Goles</th>\n"
                "</tr>\n"
                "</thead>\n")

        ####### IMPRIMIR LOS OBJETOS

        f.write("<tr><td>" + condicion + "</td><td>" + equipo + "</td><td>" + str(goles) + "</td>\n</tr>")

        f.write("</table>\n"

                "</div>\n"
                "</body>\n"
                "</html>")

    webbrowser.open_new_tab('goles.html')

